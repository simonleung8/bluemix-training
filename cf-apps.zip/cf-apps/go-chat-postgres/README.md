Go-Chat-Postgress
-----------------

This application is a simple chat application that is used to demo
Bluemix and some of the services offered.

# Getting Started
-----------------

1. To start, make sure that you have an account on [Bluemix.net](https://new-console.ng.bluemix.net)
   and have logged in.

2. Create an ElephanSQL database instace from the Bluemix Catalog.



# Local Development

1. You must have a connection to an instance of a Postgres dtabase for this
   application. To set the instance locally, you can set the
   `POSTGRES_URL=[url]` environment variable to the databse connection url.
