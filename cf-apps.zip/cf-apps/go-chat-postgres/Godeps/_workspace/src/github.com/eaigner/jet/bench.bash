#!/bin/bash
go test -bench . -benchtime 10s -cpuprofile cpu.out