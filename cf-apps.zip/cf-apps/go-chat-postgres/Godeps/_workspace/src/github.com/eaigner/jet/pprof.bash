#!/bin/bash
go tool pprof --text --cum jet.test cpu.out